/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package zoomanagementsystem;
/**
 *
 * @author earnest
 */
public class Animal {
    private String name;
    private int age;
    public void makeSound() {
        // Implementation to be overridden by subclasses
    }

    public void eat() {
        // Implementation to be overridden by subclasses
    }
}
